# Mintegral Adapter plugin for Google Mobile Ads SDK for Unity

This is a plugin to be used in conjunction with the Google Mobile Ads SDK in
Unity. For requirements, instructions, and other info, see the
[Mintegral Adapter Integration Guide](https://developers.google.com/admob/unity/mediation/mintegral).

See the [changelog](https://developers.google.com/admob/unity/mediation/mintegral#mintegral-unity-mediation-plugin-changelog)
to view the version history.
